const ZONES_CONTAINER = document.getElementById('zones');
const LOADER = document.getElementById('loader');
const ERROR_BOX = document.getElementById('error');
const REFRESH_BTN = document.getElementById('refreshBtn');
const TOGGLE_BTN = document.getElementById('toggleExtraBtn');

let showExtra = true;
let lastData = {};
let zonesInitialized = false; // track if initial DOM for zones built

function setLoading(state){ LOADER.style.display = state ? 'block' : 'none'; }
function setError(msg){
  if(!msg){ ERROR_BOX.style.display='none'; ERROR_BOX.textContent=''; }
  else { ERROR_BOX.style.display='block'; ERROR_BOX.textContent = msg; }
}

function metricRow(label, value, cls=''){
  return `<div class="metric ${cls}"><span>${label}</span><strong>${value}</strong></div>`;
}

function populateDots(zoneEl, count, heat){
  const container = zoneEl.querySelector('.person-dots');
  if(!container) return;
  container.innerHTML = '';
  const dots = Math.min(count, 120);
  for(let i=0;i<dots;i++){
    const d = document.createElement('div');
    d.className = 'person-dot';
    // limbs
    const armL = document.createElement('span'); armL.className='arm left';
    const armR = document.createElement('span'); armR.className='arm right';
    const legL = document.createElement('span'); legL.className='leg left';
    const legR = document.createElement('span'); legR.className='leg right';
    d.appendChild(armL); d.appendChild(armR); d.appendChild(legL); d.appendChild(legR);
    // random placement across the entire zone
    const top = Math.random()*100; // % of height
    const left = Math.random()*100; // % of width
    d.style.top = top + '%';
    d.style.left = left + '%';
    const delay = (Math.random()*2).toFixed(2)+'s';
    d.style.animationDelay = delay;
    armL.style.animationDelay = delay;
    armR.style.animationDelay = delay;
    legL.style.animationDelay = delay;
    legR.style.animationDelay = delay;
    container.appendChild(d);
  }
}

function render(data) {
  lastData = data || {};
  const zones = Object.keys(data);
  if (!zones.length) {
    if(!zonesInitialized){
      ZONES_CONTAINER.innerHTML = '<div style="opacity:.6;text-align:center;padding:40px 0;">No zones active.</div>';
    }
    return;
  }

  // First render: build static structure
  if(!zonesInitialized){
    ZONES_CONTAINER.innerHTML = '';
    const nameMap = { zone1: 'DEEE Main Building', zone2: 'High Voltage Lab' };
    zones.forEach((zone, index) => {
      const z = data[zone];
      const live = z.zone_count ?? 0;
      const zoneCard = document.createElement('div');
      zoneCard.className = `zone fade zone-${index + 1}`;
      let heat;
      if (live < 100) heat = 'low'; else if (live < 200) heat = 'medium'; else heat = 'high';
      zoneCard.setAttribute('data-heat', heat);
      const label = nameMap[zone] || zone;
      const downArrow = (zone === 'zone1') ? '<div class="arrow-down"></div>' : '';
      const pathSVG = (zone === 'zone1') ? `
        <svg class="flow-path" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <defs><marker id="fp-arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L6,3 L0,6 z" fill="#ffffff" /></marker></defs>
          <path class="path-trace" d="M0 50 H60 Q85 50 80 78 L80 100" marker-end="url(#fp-arrow)" />
        </svg>` : (zone === 'zone2') ? `
        <svg class="flow-path" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <defs><marker id="fp-arrow2" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L6,3 L0,6 z" fill="#ffffff" /></marker></defs>
          <path class="path-trace" d="M0 85 H70 V20 H0" marker-end="url(#fp-arrow2)" />
        </svg>` : '';
      zoneCard.innerHTML = `
        <h2>${label}</h2>
        <div class="big-count">${live}</div>
        ${downArrow}
        ${pathSVG}
        <div class="person-dots"></div>
      `;
      ZONES_CONTAINER.appendChild(zoneCard);
      populateDots(zoneCard, live, heat);
    });
    zonesInitialized = true;
    requestAnimationFrame(drawInterZonePath);
    return; // initial build done
  }

  // Subsequent updates: ONLY update numbers & heat attribute
  zones.forEach((zone, index) => {
    const zData = data[zone];
    const live = zData.zone_count ?? 0;
    const zoneEl = document.querySelector(`.zone-${index+1}`);
    if(!zoneEl) return; // safety
    const bigCountEl = zoneEl.querySelector('.big-count');
    if(bigCountEl && bigCountEl.textContent !== String(live)){
      bigCountEl.textContent = live;
    }
    // Recalculate heat and update attribute if changed
    let newHeat;
    if (live < 100) newHeat = 'low'; else if (live < 300) newHeat = 'medium'; else newHeat = 'high';
    if(zoneEl.getAttribute('data-heat') !== newHeat){
      zoneEl.setAttribute('data-heat', newHeat);
    }
  });
}

// Draw walking path from Zone 1 exit (bottom area) to Zone 2 bottom-left arrow area, without overlaying zones
function drawInterZonePath(){
  const z1 = document.querySelector('.zone-1');
  const z2 = document.querySelector('.zone-2');
  if(!z1 || !z2) return;
  const containerRect = ZONES_CONTAINER.getBoundingClientRect();
  const r1 = z1.getBoundingClientRect();
  const r2 = z2.getBoundingClientRect();
  // Define exit point (Zone1): slightly below its bottom center (matching down arrow position ~80%)
  const x1 = (r1.left + r1.right)/2 - containerRect.left; // center x
  const y1 = r1.bottom - containerRect.top + 10; // just below
  // Define entry point (Zone2 bottom-left arrow target): near its left-bottom with small upward offset
  const x2 = r2.left - containerRect.left - 10; // just left outside
  const y2 = r2.bottom - containerRect.top - 50; // slightly above bottom
  // Shift the starting X a bit to the right so path originates slightly right of center exit
  const startOffset = 220; // pixels to the right
  const x1Shifted = x1 + startOffset;
  // Path will route outside: go down, across beneath zones, then up to entry
  const midY = Math.max(y1,y2) + 40; // an arc below both
  // Build cubic path: from (x1,y1) down to midY then horizontally then up
  const d = `M ${x1Shifted} ${y1} C ${x1Shifted} ${midY}, ${x2} ${midY}, ${x2} ${y2}`;
  let svg = document.getElementById('inter-zone-path');
  if(!svg){
    svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.id = 'inter-zone-path';
    svg.setAttribute('class','inter-zone-path');
    svg.style.position='absolute';
    svg.style.inset='0';
    svg.style.pointerEvents='none';
    svg.style.zIndex='1'; // behind zone cards (cards likely higher default stacking due to later placement)
    // Place svg inside parent of zones container for full coverage
    (ZONES_CONTAINER.parentElement || document.body).appendChild(svg);
  }
  svg.setAttribute('viewBox',`0 0 ${containerRect.width} ${containerRect.height+80}`);
  svg.setAttribute('width',containerRect.width);
  svg.setAttribute('height',containerRect.height+80);
  svg.style.left = containerRect.left + 'px';
  svg.style.top = containerRect.top + 'px';
  let path = svg.querySelector('path');
  if(!path){
    path = document.createElementNS('http://www.w3.org/2000/svg','path');
    svg.appendChild(path);
  }
  path.setAttribute('d', d);
  path.setAttribute('fill','none');
  path.setAttribute('stroke','#7dd3fc'); // distinct cyan color
  path.setAttribute('stroke-width','4');
  path.setAttribute('stroke-linecap','round');
  path.setAttribute('stroke-linejoin','round');
  path.setAttribute('stroke-dasharray','10 12');
  // simple animation by offset
  path.style.animation = 'connectorDash 3s linear infinite';
}

// Inject dash animation keyframes (once)
(function ensureConnectorAnim(){
  if(document.getElementById('connector-dash-style')) return;
  const style = document.createElement('style');
  style.id = 'connector-dash-style';
  style.textContent = `@keyframes connectorDash { to { stroke-dashoffset: -44; } }`;
  document.head.appendChild(style);
})();

async function load(force=false){
  try {
    if(force) setLoading(true);
    setError('');
    const res = await fetch('/api/zone_counters?_=' + Date.now());
    if(!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    render(data);
  } catch(e){
    console.error(e);
    setError('Failed to load counters. ' + e.message + ' (retrying...)');
  } finally {
    setLoading(false);
  }
}

setLoading(true);
load(true);
setInterval(load, 2000);